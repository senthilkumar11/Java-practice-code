import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-login-container1',
  templateUrl: './login-container1.component.html',
  styleUrls: ['./login-container1.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginContainer1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

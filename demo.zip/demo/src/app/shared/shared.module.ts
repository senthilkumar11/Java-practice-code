import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NbCardModule, NbInputModule } from '@nebular/theme';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    NbCardModule,
    NbInputModule
  ],
  exports: [NbCardModule, NbInputModule]
})
export class SharedModule { }
